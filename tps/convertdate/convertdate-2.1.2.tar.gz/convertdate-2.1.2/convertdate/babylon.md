Babylonian Calendar
-------------------

The Babylonian calendar is a lunisolar calender with twelve months of 28 or 29 days. Leap months are inserted in a 19-year cycle. In the system used for most of the calendar's existence, eight months were inserted in each cycle. This 19-year pattern relies on the observation that 236 lunar months occur in very nearly the same time as 19 tropical years (equinox-to-equinox). It's called the Metonic cycle after the Athenian who "discovered" it several hundred years after the Babylonians put it into use.

* irregular lunations
** parker and dubberst, and corrections

* describe workings of module

* analeptic calendar
** 687 year corrections to metonic cycle

* roots, reform by nabopolassar