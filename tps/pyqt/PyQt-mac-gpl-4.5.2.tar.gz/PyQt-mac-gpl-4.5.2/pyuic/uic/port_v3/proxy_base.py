from PyQt4.uic.Compiler.proxy_type import ProxyType


class ProxyBase(metaclass=ProxyType):
    pass
