# Import the StringIO object.
try:
    from cStringIO import StringIO
except ImportError:
    from StringIO import StringIO
