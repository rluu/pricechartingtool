from PyQt4.uic.Compiler.proxy_type import ProxyType


class ProxyBase(object):
    __metaclass__ = ProxyType
