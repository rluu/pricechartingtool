# Import the StringIO object.
from io import StringIO
