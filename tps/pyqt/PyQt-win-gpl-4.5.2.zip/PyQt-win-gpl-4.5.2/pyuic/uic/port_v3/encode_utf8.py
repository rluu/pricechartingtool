def encode_utf8(s):
    # Python v3 will convert to UTF-8 anyway, so there is nothing to do.
    return s
