def encode_utf8(s):
    return s.encode('UTF-8')
