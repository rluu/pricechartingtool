<!DOCTYPE TS><TS>
<context>
    <name>MainWindow</name>
    <message>
        <source>Title</source>
        <translation type="unfinished">Titulo</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished">Texto</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="unfinished">Lengua</translation>
    </message>
</context>
</TS>
