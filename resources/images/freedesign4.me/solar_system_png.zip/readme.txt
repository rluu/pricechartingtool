= = = = = = = = = = = = = =
Solar System Icons
= = = = = = = = = = = = = =

By: Dan Wiersema
Website: www.danwiersema.com

Description: 
13 solar system icons inspired by objects in the Milky Way. Contains the Sun, Moon, 8 planets, and 3 dwarf planets.

License:
Free for non-commercial use. These icons are only for personal use only. You may not redistribute or modify these icons. Distributing these icons commercially or using them with intent for monetary gain is prohibited.

If you are interested in using these icons commercially please contact Guifx. (www.guifx.com)
